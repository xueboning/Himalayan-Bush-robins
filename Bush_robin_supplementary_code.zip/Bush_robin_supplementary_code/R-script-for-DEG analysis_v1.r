#This script is used to quantify the number of differentially expressed genes (DEGs) and to provide an overview of gene expression plasticity across different treatments and species.
#The filtered expression count matrices for both species and grouping data are used as input files.
#Note1: Since our analysis includes two species and four tissues, for demonstration purposes, this script will focus on the flight muscle of Tarsiger chrysaeus (TC) as an example.
#Note2: The comparison between cold-hypoxia and warm-normoxia (CH vs. WN) will then be used to identify DEGs.

#Install the dependencies package
# BiocManager::install("DESeq2") 
# install.packages("dplyr")
# install.packages("openxlsx")
# install.packages("ggplot2")

#Library the dependencies package
rm(list = ls())
library(DESeq2); packageVersion("DESeq2") 
library(ggplot2)
library(openxlsx)
library(dplyr)


#Load grouping data
treat<-read.xlsx("../data/sample_id.xlsx",sheet=1)
treat$ID<-as.character(treat$ID)
TC<-treat[c(1:5,11:16,23:28,34:39),]
TC_c_h<-treat[1:5,]     #cold/hypoxia of TC
TC_c_n<-treat[23:28,]   #cold/normoxia of TC
TC_w_h<-treat[11:16,]   #warm/hypoxia of TC
TC_w_n<-treat[34:39,]   #warm/normoxia of TC

#Load expression data (count)
w_tc <- read.csv(file = "../data/count_muscle_tc_filter.csv", header = T, row.names = 1)
#set the dataset for comparison
TC_overall <- w_tc[,rbind(TC_c_h, TC_w_n)$ID]
list_expr <-list(TC_overall=TC_overall)
expr_name<- c("TC_overall");expr_name

#specify control group
conditionTC_overall <- factor(c(rep("control",nrow(TC_c_h)), rep("treat",nrow(TC_w_n))))
list_condition <-list(conditionTC_overall=conditionTC_overall)
condition_name<-c("conditionTC_overall");condition_name

#building group files
coldataTC_overall <- data.frame(row.names = colnames(TC_overall), conditionTC_overall );coldataTC_overall
list_coldata <-list(coldataTC_overall=coldataTC_overall)

dds_TC_overall <- DESeqDataSetFromMatrix(countData=TC_overall, colData =coldataTC_overall, design= ~conditionTC_overall)
list_dds <-list(dds_TC_overall=dds_TC_overall)
save(list_expr,expr_name, list_condition,condition_name, list_coldata, list_dds, file = "../results/data_for_deseq2_muscle.RData")

############


DEG_num <-data.frame(allSigDEG=numeric(),UP=numeric(),DOWN=numeric())

#for (i in 1:5){
    i=1
    dds_A <- DESeq(list_dds[[i]])
    res_A <- results(dds_A, contrast=c(condition_name[i],"treat","control"))
    
    pdf(paste("../results/DESeq_res_plot_muscle_",expr_name[i],".pdf",sep=""));plotMA(res_A);dev.off()

    res_A_1 <- res_A[order(res_A$padj),]
    resdata_A <- merge(as.data.frame(res_A_1), as.data.frame(counts(dds_A, normalized=TRUE)), by="row.names", sort=FALSE) 
    write.csv(resdata_A, paste("../results/DEGs_all_muscle_",expr_name[i],".csv",sep=""), row.names=FALSE)

    #Sig DEGs
    res_A_2 <- res_A[order(res_A$log2FoldChange),]
    diff_A <- subset(res_A_2, padj < 0.05 & (log2FoldChange > 1 | log2FoldChange < -1))
    diff_A$change = as.factor(ifelse(diff_A$padj < 0.05 & abs(diff_A$log2FoldChange) > 1,ifelse(diff_A$log2FoldChange > 1 ,'UP','DOWN'),'NOT')) 
    diff_data_A <- merge(as.data.frame(diff_A), as.data.frame(counts(dds_A, normalized=TRUE)), by="row.names", sort=FALSE)
    write.csv(diff_data_A, paste("../results/Sig_DEGs_muscle_",expr_name[i],".csv",sep=""), row.names=FALSE)
    
    DEG_num[i,1]<- dim(diff_A)[1] #all sig DEGs
    DEG_num[i,2]<- nrow(subset(diff_data_A,change=="UP")) #UP
    DEG_num[i,3]<- nrow(subset(diff_data_A,change=="DOWN")) #DOWN
    
    ##############################
    
    #Volcano Plot
    resdata_A$change <- as.factor(
        ifelse(
            resdata_A$padj<0.05 & abs(resdata_A$log2FoldChange)>1,
            ifelse(resdata_A$log2FoldChange>1, "Up", "Down"),
        "NoDiff"
        )
    )
    valcano <- ggplot(data=resdata_A, aes(x=log2FoldChange, y=-log10(padj), color=change)) + 
        geom_point(alpha=0.8, size=1.2) +  
        theme_bw(base_size=15) + 
        theme(
            panel.grid.minor=element_blank(),
            panel.grid.major=element_blank(),
            plot.title=element_text(size = 14, face="plain"),
            axis.title.x = element_text(size = 13, face="plain"), 
            axis.title.y = element_text(size = 13, face="plain") 
        ) + 
        ggtitle(paste("muscle_",expr_name[i],sep="")) + 
        scale_color_manual(name="", values=c("#993333", "#003399", "#333333"), limits=c("Up", "Down", "NoDiff")) + 
        geom_vline(xintercept=c(-1, 1), lty=2, col="gray", lwd=0.5) + 
        geom_hline(yintercept=-log10(0.05), lty=2, col="gray", lwd=0.5)
    ggsave(valcano, file=paste("../results/ValcanoPlot_muscle_",expr_name[i],".pdf",sep=""),width = 5.35,height = 4.7)

#}

rownames(DEG_num)<-expr_name
