#This script is used to represent the direction and magnitude of divergence between the centroids of vectors for different acclimation conditions.
#The input files include the log-transformed TPM expression profiles of Hub genes identified through WGCNA, as well as a grouping file containing the treatments.
#Note: Since we analyzed four tissues, for simplicity, this script will focus on the flight muscle of Tarsiger chrysaeus (TC) and Tarsiger indicus (TI) as an example, using data from the four treatment conditions.


#Install the dependencies package
# install.packages("dplyr")
# install.packages("Rmisc")
# install.packages("reshape2")
# install.packages("FactoMineR")
# install.packages("factoextra")
# install.packages("plotrix")


#Library the dependencies package
rm(list = ls())
library(dplyr)
library(Rmisc)
library(reshape2)
library(FactoMineR) 
library(factoextra)
library(plotrix) 


#Load expression data of hub genes
exp0<-read.table("../data/6.3.3 muscle_hubgene_expr_4treatments.csv",header = T,row.names=1,sep = ",")
exp1<- as.data.frame(t(exp0))

#Add the grouping information
group0<-read.table("../data/sample_treatment.csv",row.names=1,header = T,sep = ",")[,1, drop = FALSE]
groups<- filter(group0,rownames(group0) %in% rownames(exp1))

#PCA 
gene.pca <- PCA(exp1, scale.unit = TRUE, graph = FALSE, ncp = min(nrow(exp1), ncol(exp1))); plot(gene.pca) 
eigen.val <- as.data.frame(get_eigenvalue(gene.pca));eigen.val
pca_sample <- cbind(data.frame(gene.pca$ind$coord), groups)

#5000 simulations
exp<-melt(pca_sample,id.vars=c("group1"))
md<-summarySE(exp, measurevar="value", groupvars=c("variable","group1"),na.rm=T)
q<-levels(factor(pca_sample$group1))
observed<-list() 
simulated<-list()

for (j in 1:length(q)){
    des2 <- subset(md,md$group1==q[j])
    # array for storing means
    n.sim<-5000
    means <- sds <- array(NA,dim=c(n.sim,dim(des2)[1]))
    colnames(means) <- colnames(sds) <- des2$variable
    # start simulation
    for(t in 1:n.sim){
        for(s in 1:dim(des2)[1]){
            draws <- rnorm(des2$N[s],des2$value[s],des2$sd[s]) 
            means[t,s] <- mean(draws)  
            sds[t,s] <- sd(draws)
        }
    }
    # store means in data object
    observed[[j]] <- list(means=des2$value,sds=des2$sd)
    simulated[[j]] <- list(means=means,sds=sds)
}
save(simulated, file = "../data/4treatments_simulated 5000 times_muscle.RData")


######################################

# get treatments means 
#TC
mean_TC.C.H <- simulated[[1]]$means
mean_TC.C.N <- simulated[[2]]$means
mean_TC.W.H <- simulated[[3]]$means
mean_TC.W.N <- simulated[[4]]$means
#TI
mean_TI.C.H <- simulated[[5]]$means
mean_TI.C.N <- simulated[[6]]$means
mean_TI.W.H <- simulated[[7]]$means
mean_TI.W.N <- simulated[[8]]$means

# Centralize  means (C.H as control)
#TC
zmean_TC.C.H <- mean_TC.C.H-mean_TC.C.H 
zmean_TC.C.N <- mean_TC.C.N-mean_TC.C.H
zmean_TC.W.H <- mean_TC.W.H-mean_TC.C.H  
zmean_TC.W.N <- mean_TC.W.N-mean_TC.C.H 
#TI
zmean_TI.C.H <- mean_TI.C.H-mean_TI.C.H 
zmean_TI.C.N <- mean_TI.C.N-mean_TI.C.H
zmean_TI.W.H <- mean_TI.W.H-mean_TI.C.H
zmean_TI.W.N <- mean_TI.W.N-mean_TI.C.H


# Plasticity vector
# variables related to the four treatments (cold/hypoxia, cold/normoxia, warm/hypoxia, warm/normoxia) will be abbreviated as A, B, C, D
#TC
PV_TC.AB <- lapply(seq_len(n.sim), function(i,x) x[i,], x=zmean_TC.C.N-zmean_TC.C.H)
PV_TC.AC <- lapply(seq_len(n.sim), function(i,x) x[i,], x=zmean_TC.W.H-zmean_TC.C.H)
PV_TC.AD <- lapply(seq_len(n.sim), function(i,x) x[i,], x=zmean_TC.W.N-zmean_TC.C.H)
#TI
PV_TI.AB <- lapply(seq_len(n.sim), function(i,x) x[i,], x=zmean_TI.C.N-zmean_TI.C.H)
PV_TI.AC <- lapply(seq_len(n.sim), function(i,x) x[i,], x=zmean_TI.W.H-zmean_TI.C.H)
PV_TI.AD <- lapply(seq_len(n.sim), function(i,x) x[i,], x=zmean_TI.W.N-zmean_TI.C.H)



#Angle of plasticity vector 
tc_PV.AB_on_PV.AC<-
tc_PV.AB_on_PV.AD<-
tc_PV.AC_on_PV.AD<-

ti_PV.AB_on_PV.AC<-
ti_PV.AB_on_PV.AD<-
ti_PV.AC_on_PV.AD<-

tc_angle_BAC<-
tc_angle_BAD<-
tc_angle_CAD<- 

ti_angle_BAC<-
ti_angle_BAD<-
ti_angle_CAD<- array(NA,dim=c(5000,1))


scalar.projection <- function(a,b,relative=FALSE){
    # project vector a on vector b
    if(relative){
        return((a%*%b/sqrt(sum(b^2)))[1,1]/sqrt(sum(b^2)))
    }else{
        return((a%*%b/sqrt(sum(b^2)))[1,1])
    }
}


for (k in 1:1) { #TC
    tc_PV.AB_on_PV.AC[,k] <- mapply(scalar.projection,PV_TC.AB,PV_TC.AC, relative=TRUE)
    tc_PV.AB_on_PV.AD[,k] <- mapply(scalar.projection,PV_TC.AB,PV_TC.AD, relative=TRUE)
    tc_PV.AC_on_PV.AD[,k] <- mapply(scalar.projection,PV_TC.AC,PV_TC.AD, relative=TRUE)
}

for (k in 1:1) { #TI
    ti_PV.AB_on_PV.AC[,k] <- mapply(scalar.projection,PV_TI.AB,PV_TI.AC, relative=TRUE)
    ti_PV.AB_on_PV.AD[,k] <- mapply(scalar.projection,PV_TI.AB,PV_TI.AD, relative=TRUE)
    ti_PV.AC_on_PV.AD[,k] <- mapply(scalar.projection,PV_TI.AC,PV_TI.AD, relative=TRUE)
}



# Angle between pasticity vector A and plasticity vector B in 【0 to 180】 degree range
angle180 <- function(a,b){
    angle <- acos( sum(a*b) / ( sqrt(sum(a * a)) * sqrt(sum(b * b)) ) ) * (180/pi)
    if(is.nan(angle)){
        return(0)
    }else{
        return(angle)    
    }
}
    
#TC TI
for (k in 1:1) {
    tc_angle_BAC[,k] <- mapply(angle180,PV_TC.AB,PV_TC.AC)
    tc_angle_BAD[,k] <- mapply(angle180,PV_TC.AB,PV_TC.AD)
    tc_angle_CAD[,k] <- mapply(angle180,PV_TC.AC,PV_TC.AD)
}
    
for (k in 1:1) {
    ti_angle_BAC[,k] <- mapply(angle180,PV_TI.AB,PV_TI.AC)
    ti_angle_BAD[,k] <- mapply(angle180,PV_TI.AB,PV_TI.AD)
    ti_angle_CAD[,k] <- mapply(angle180,PV_TI.AC,PV_TI.AD)
}


ang<-cbind(tc_angle_BAC,tc_angle_BAD,tc_angle_CAD,ti_angle_BAC,ti_angle_BAD,ti_angle_CAD)
colnames(ang)<-c("TC_BAC","TC_BAD","TC_CAD","TI_BAC","TI_BAD","TI_CAD")
write.csv(ang,"../data/4treatments_vector_angle_muscle.csv",row.names=F)



#Length of plasticity vector 
tc_length_AB<-
tc_length_AC<-
tc_length_AD<-
tc_length_BD<-
tc_length_CD<-

ti_length_AB<-
ti_length_AC<-
ti_length_AD<-
ti_length_BD<-
ti_length_CD<-array(NA,dim=c(5000,1))
    
for (k in 1:1) { 
    tc_length_AB[,k] <- apply(zmean_TC.C.N-zmean_TC.C.H,1,function(v){sqrt(sum(v^2))})
    tc_length_AC[,k] <- apply(zmean_TC.W.H-zmean_TC.C.H,1,function(v){sqrt(sum(v^2))})
    tc_length_AD[,k] <- apply(zmean_TC.W.N-zmean_TC.C.H,1,function(v){sqrt(sum(v^2))})
    tc_length_BD[,k] <- apply(zmean_TC.W.N-zmean_TC.C.N,1,function(v){sqrt(sum(v^2))})
    tc_length_CD[,k] <- apply(zmean_TC.W.N-zmean_TC.W.H,1,function(v){sqrt(sum(v^2))})

}  

for (k in 1:1) { 
    ti_length_AB[,k] <- apply(zmean_TI.C.N-zmean_TI.C.H,1,function(v){sqrt(sum(v^2))})
    ti_length_AC[,k] <- apply(zmean_TI.W.H-zmean_TI.C.H,1,function(v){sqrt(sum(v^2))})
    ti_length_AD[,k] <- apply(zmean_TI.W.N-zmean_TI.C.H,1,function(v){sqrt(sum(v^2))})
    ti_length_BD[,k] <- apply(zmean_TI.W.N-zmean_TI.C.N,1,function(v){sqrt(sum(v^2))})
    ti_length_CD[,k] <- apply(zmean_TI.W.N-zmean_TI.W.H,1,function(v){sqrt(sum(v^2))})
}  

len<-cbind(tc_length_AB,tc_length_AC,tc_length_AD,tc_length_BD,tc_length_CD,ti_length_AB,ti_length_AC,ti_length_AD,ti_length_BD,ti_length_CD)
colnames(len)<-c("TC_C.N-C.H","TC_W.H-C.H","TC_W.N-C.H","TC_W.N-C.N","TC_W.N-W.H","TI_C.N-C.H","TI_W.H-C.H","TI_W.N-C.H","TI_W.N-C.N","TI_W.N-W.H")
write.csv(len,"../data/4treatments_vector_length_muscle.csv",row.names=F)

