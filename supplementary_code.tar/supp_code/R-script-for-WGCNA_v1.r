#Notes:as we have four tissues used in our analysis, for simplicity, this script will just use the muscle of Tarsiger chrysaeus(TC) and Tarsiger indicus(TI) among four treatments as an example.
#This script used for examining gene expression associated with the four different treatments between two species

#Install the dependencies package
# BiocManager::install("WGCNA", force = TRUE)
# install.packages("ggplot2")
# install.packages("openxlsx")
# install.packages("dplyr")
# install.packages("stringr")

rm(list = ls())
library(WGCNA); packageVersion("WGCNA") # v1.41.1
library(openxlsx)
library(dplyr)
library(ggplot2)
library(stringr) 

options(stringsAsFactors = FALSE)  
enableWGCNAThreads()
allowWGCNAThreads()


#Load adjusted expression data (log2(tpm+1))
data_tcti = read.table("../data/LOG_tpm_adjusted_muscle_tcti.csv",sep = ",", header = TRUE,row.names=1)
datExpr0 = as.data.frame(t(data_tcti))
str(datExpr0)
gsg = goodSamplesGenes(datExpr0, verbose = 3)
gsg$allOK

#########################

sampleTree = hclust(dist(datExpr0), method = "average") 
plot(sampleTree, 
    main = "TCTI_muscle_Sample clustering to detect outliers",
    sub="", 
    xlab="", 
    cex.lab = 1.5,
    cex.axis = 1.5, 
    cex.main = 2
)
abline(h = 90, col = "red")  
clust = cutreeStatic(sampleTree, cutHeight = 90, minSize = 10)  ; table(clust)
keepSamples = (clust==1) 
datExpr = datExpr0[keepSamples, ]
nGenes = ncol(datExpr); nSamples = nrow(datExpr);nGenes;nSamples

#########################

#Load treatment data
traitData = read.csv("../data/traits_all.csv",sep = ",", header = TRUE,row.names=1)
allTraits = traitData[, c(1:2)] 
traitRows = match(rownames(datExpr), rownames(allTraits)) 
datTraits = allTraits[traitRows, ]

#########################

sampleTree2 = hclust(dist(datExpr), method = "average")
traitColors = numbers2colors(datTraits, signed = FALSE)

pdf("../results/1.2 TCTI_muscle_Sample dendrogram and trait heatmap.pdf", width = 10, height = 5)    #plot the sample dendrogram and the colors underneath.
par(oma=c(1,3,1,1)) 
par(mar=c(1,4,1,1) +1) 
plotDendroAndColors(sampleTree2, traitColors,
                    groupLabels = names(datTraits), 
                    main = "TCTI_muscle_Sample dendrogram and trait heatmap"
)
dev.off() 

#########################

powers = c(c(1:10), seq(from = 12, to=20, by=2))
sft = pickSoftThreshold(datExpr, powerVector = powers, verbose = 5) #使用网络拓扑分析函数
str(sft) 

softPower <- sft$powerEstimate
softPower 
write.csv(sft,"../results/1.2 sft_tcti_muscle.csv", row.names=TRUE)


pdf("../results/2.1 Soft-thresholding powers.pdf", width = 9, height = 5)
par(mfrow = c(1,2)); cex1 = 0.9;
plot(
    sft$fitIndices[,1], 
    -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
    xlab="Soft Threshold (power)",
    ylab="Scale Free Topology Model Fit,signed R^2",type="n",
    main = paste("TCTI_muscle_Scale independence"))
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
    labels=powers,cex=0.9,col="red");
abline(h=0.90,col="red")

plot(sft$fitIndices[,1],
    sft$fitIndices[,5],
    xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",
    main = paste("Mean connectivity"))
text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=0.9,col="red")
dev.off() 

#########################

net = blockwiseModules(datExpr, 
                       power = softPower,            
                       maxBlockSize = 10000, 
                       TOMType = "unsigned",  
                       minModuleSize = 30,
                       reassignThreshold = 0, 
                       mergeCutHeight = 0.25,
                       numericLabels = TRUE,  
                       pamRespectsDendro = FALSE,
                       saveTOMs = TRUE,   
                       saveTOMFileBase = "../results/2.2 TCTI_muscle_bush_robin_TOM",
                       verbose = 3)
table(net$colors) 
moduleLabels = net$colors 
moduleColors = labels2colors(net$colors); table(moduleColors)    # Convert labels to colors for plotting
MEs = net$MEs
mergedColors = labels2colors(net$colors); table(mergedColors)
pdf("../results/2.3.1 TCTI_muscle_Dendrogram and the modules.pdf", width = 12, height = 9)
plotDendroAndColors(net$dendrograms[[1]], moduleColors[net$blockGenes[[1]]],
                    "Module colors",
                    dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05
                    ) 
dev.off()


colnames(MEs) <- paste0("ME", labels2colors(as.numeric(str_replace_all(colnames(MEs),"ME",""))))
MEs_new <- orderMEs(MEs)
pdf("../results/2.3.1 Eigengene adjacency heatmap.pdf", width = 10, height = 12);
plotEigengeneNetworks(
    MEs_new ,
    "Eigengene adjacency heatmap",
    marDendro = c(3, 3, 2, 4),
    marHeatmap = c(3, 4, 2, 2),
    plotDendrograms = T,
    xLabelsAngle = 90
    )
dev.off()

#########################

# Recalculate MEs with color labels
# Display the correlation values within a heatmap plot
nGenes = ncol(datExpr); nSamples = nrow(datExpr)
MEs0 <- moduleEigengenes(datExpr, moduleColors)$eigengenes 
MEs0 <- orderMEs(MEs0)
write.csv(MEs0,"../results/3.1 TCTI_muscle_MEs0.csv")

moduleTraitCor = cor(MEs0, datTraits, use = "p") 
moduleTraitPvalue = corPvalueStudent(moduleTraitCor, nSamples) 

pdf("../results/3.1 Module-trait relationships.pdf", width = 10, height = 6)    
textMatrix =  paste(signif(moduleTraitCor, 2), "\n(",
                           signif(moduleTraitPvalue, 1), ")", sep = "");
dim(textMatrix) = dim(moduleTraitCor)
par(mar = c(6, 8.5, 3, 3))
labeledHeatmap(Matrix = moduleTraitCor,
               xLabels = names(datTraits),
               yLabels = names(MEs0),
               ySymbols = names(MEs0),
               colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = textMatrix,
               setStdMargins = FALSE,
               cex.text = 0.45,
               zlim = c(-1,1),
               main = paste("3.1 TCTI_muscle_Module-trait relationships")
)
dev.off()

#########################

#ModuleMembership(MM)
geneModuleMembership = as.data.frame(cor(datExpr, MEs, use = "p")) 
modNames = substring(names(MEs), 3); names(geneModuleMembership) = paste("MM", modNames, sep="")
MMPvalue = as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership), nSamples)); names(MMPvalue) = paste("p.MM", modNames, sep="")

#Output the GS-value  and P-values of treatment associated genes 
color<-as.data.frame(mergedColors)
#for (i in 2:10){
    i=2
    treat = as.data.frame(datTraits[,i])
    names(treat) = colnames(datTraits)[i]
    #GS
    geneTraitSignificance = as.data.frame(cor(datExpr, treat, use = "p")) ; names(geneTraitSignificance) = paste("GS.", names(treat), sep="")
    GS_abs<-abs(geneTraitSignificance); names(GS_abs) = paste("abs.GS.", names(treat), sep="")
    #GS.Pvalue
    GS_Pvalue = as.data.frame(corPvalueStudent(as.matrix(geneTraitSignificance), nSamples)); names(GS_Pvalue) = paste("p.GS.", names(treat), sep="")
    #merge
    GS_color <- GS_abs
    GS_color $ Pvalue<- GS_Pvalue[,1]
    GS_color $ color <- color$mergedColors
    treat_ModuleSignificance <- tapply(as.numeric(unlist(GS_abs)),mergedColors,mean,na.rm=T) 

    write.csv(GS_abs,paste("../results/4.2.",i," TCTI_muscle_GS_abs_",names(treat),".csv",sep=""))
    write.csv(GS_Pvalue,paste("../results/4.2.",i," TCTI_muscle_GS_Pvalue_",names(treat),".csv",sep=""))
    write.csv(GS_color,paste("../results/4.2.",i," TCTI_muscle_GS_color_",names(treat),".csv",sep=""))
    write.csv(treat_ModuleSignificance ,paste("../results/4.2.",i," TCTI_muscle_GS_ModuleSignificance_",names(treat),".csv",sep=""))


    c<-levels(factor(labels2colors(net$colors)))
    for (j in c) {   
        module = j # Select module
        column = match(module, modNames)
        moduleGenes = moduleColors==module
        pdf(paste("../results/4.3.",i," MM vs GS_",names(treat),"_",module,".pdf",sep=""), width = 7, height = 7)
        par(mfrow = c(1,1));
        verboseScatterplot(abs(geneModuleMembership[moduleGenes, column]),
                    GS_abs[moduleGenes, 1],
                    xlab = paste("Module Membership in", module, "module"),
                    ylab = "Gene significance ",
                    main = paste("Module membership vs. gene significance\n"),
                    cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = module)
        dev.off()
    }

    c<-levels(factor(labels2colors(net$colors)))
    for (j in c) {  
        module = j # Select module
        column = match(module, modNames)
        moduleGenes = moduleColors==module
        name<-rownames(geneModuleMembership)[moduleGenes];View(name) 

        a<-abs(dplyr::select(geneModuleMembership,column));View(a) 
        mm<-filter(a, rownames(a) %in% name) ;View(mm)
        gs<-filter(GS_abs,rownames(GS_abs) %in% name );View(gs) 
        gs_pvalue<-filter(GS_Pvalue,rownames(GS_Pvalue) %in% name );View(gs_pvalue) 
        d<-cbind(gs,gs_pvalue);e<-cbind(mm,d);View(e) 
        f <-filter(e,e[,1]>0.8,e[,2]>0.2);View(f) 
        f1<-filter(e,e[,3]<0.05);View(f1) 

        write.csv(f,paste("../results/4.4.",i," hubgene0_",names(treat),"_",module,".csv",sep=""))
        write.csv(f1,paste("../results/4.4.",i," hubgene_Pvalue_",names(treat),"_",module,".csv",sep=""))
    }
#}

